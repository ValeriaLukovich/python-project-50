__all__ = ["generate_diff",
        'stylish'
        ]
