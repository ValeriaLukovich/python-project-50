import json


def json_format(lists):
    return json.dumps(lists)
