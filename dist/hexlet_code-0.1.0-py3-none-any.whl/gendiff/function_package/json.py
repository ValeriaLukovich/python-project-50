import json


def json_f(lists):
    return json.dumps(lists)
