def make_dict(name, number, key, value):
    dictionary = {"status": name, "depth": number, "key": key, "value": value}
    return dictionary
