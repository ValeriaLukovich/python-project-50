### Hexlet tests and linter status:
[![Actions Status](https://github.com/ValeriaLukovich/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/ValeriaLukovich/python-project-50/actions)


[![Maintainability](https://api.codeclimate.com/v1/badges/35f5e49a65a4753a0eda/maintainability)](https://codeclimate.com/github/ValeriaLukovich/python-project-50/maintainability)


[![Test Coverage](https://api.codeclimate.com/v1/badges/35f5e49a65a4753a0eda/test_coverage)](https://codeclimate.com/github/ValeriaLukovich/python-project-50/test_coverage)


[![asciicast](https://asciinema.org/a/inetvdnUzcKhvW8sX29m9vKXb.svg)](https://asciinema.org/a/inetvdnUzcKhvW8sX29m9vKXb)


[![asciicast](https://asciinema.org/a/lLoPrLBbrI8dWBCcVFaSCR4KD.svg)](https://asciinema.org/a/lLoPrLBbrI8dWBCcVFaSCR4KD)


[![asciicast](https://asciinema.org/a/srUFI8grS3NaIA0AakIZpB1VE.svg)](https://asciinema.org/a/srUFI8grS3NaIA0AakIZpB1VE)


[![asciicast](https://asciinema.org/a/M6hKfdl4VyIzwybjxKBwrtF0R.svg)](https://asciinema.org/a/M6hKfdl4VyIzwybjxKBwrtF0R)
